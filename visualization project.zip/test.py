from flask import Flask, request, render_template, session, redirect, url_for, make_response
import numpy as np
import pandas as pd
import json
import matplotlib.pyplot as plt 
import itertools
import os 

app = Flask(__name__)

@app.route('/')
def display():
    plt.clf()
    plt.rcParams.update({'figure.max_open_warning': 0})
    df = pd.read_json('data.json')

    age = []
    experience = []
    names = []
    for index, row in df.iterrows():
        year = pd.to_numeric(row['birthday'].split('-')[0])
        age.append(2019 - year)
        exp_year = pd.to_numeric(row['memberSince'].split('-')[0])
        experience.append(2019 - exp_year)
        names.append(row['name']['first'])
    
    plt.title("Graph mapping age group and experience")
    plt.figure(figsize=(16, 6))
    plt.scatter(age, experience)
    plt.xlabel('age')
    plt.ylabel('experience')

    
    #os.remove('C:/Users/mjeevan/Downloads/fsnd-virtual-machine/FSND-Virtual-Machine/vagrant/visualization/static/images/my_plot1.png')
    plt.savefig('static/images/my_plot1.png')
    plt.close()
    return render_template('main.html', image_name = 'my_plot1.png')

@app.route('/gender/')
def displayGender():
    df = pd.read_json('data.json')

    labels = ['female', 'male']
    total = []

    total =  df.groupby(['gender'])['name'].count()
    colors = ['gold', 'yellowgreen']
    explode = (0.1, 0)  # explode 1st slice
    plt.pie(total, explode=explode, labels=labels, colors=colors,
    autopct='%1.1f%%', shadow=True, startangle=140)
    plt.title("Male- Female ratio in group")
 
    plt.axis('equal')
    #os.remove('C:/Users/mjeevan/Downloads/fsnd-virtual-machine/FSND-Virtual-Machine/vagrant/visualization/static/images/my_plot2.png')
    plt.savefig('static/images/my_plot2.png', dpi = 100)
    plt.close()
    return render_template('main.html', image_name = 'my_plot2.png')

@app.route('/likesgroup/')
def likesGroup():
   df = pd.read_json('data.json')
   labels = []
   for index, row in df.iterrows():
       labels.extend(row['likes'])
   labels = list(dict.fromkeys(labels))

   dicts = {}

   for l in labels:
       dicts[l] = 0

   for index, row in df.iterrows():
       for r in row['likes']:
           value =  dicts[r]
           temp = {r : value +1}
           dicts.update(temp)
    
   plt.pie(dicts.values(), labels = labels, autopct='%1.1f%%', shadow = True, startangle = 140)
   plt.title("Percentage of people with same likes")
   #os.remove('C:/Users/mjeevan/Downloads/fsnd-virtual-machine/FSND-Virtual-Machine/vagrant/visualization/static/images/my_plot3.png')
   plt.savefig('static/images/my_plot3.png', dpi = 100)
   plt.close()
   return render_template('main.html', image_name = 'my_plot3.png')

@app.route('/regiongroup/')
def regiongroup():
    df = pd.read_json('data.json')
    states = []
    fullStateList = []
    state_count = []
    for index, row in df.iterrows():
        states.append(row['contact']['address']['state'])

    fullStateList = list(dict.fromkeys(states))
    
    for state in fullStateList:
        state_count.append(states.count(state))

    plt.figure(figsize=(15, 6))
    plt.scatter(fullStateList, state_count)
    plt.xlabel('State')
    plt.ylabel('People count')
    #os.remove('C:/Users/mjeevan/Downloads/fsnd-virtual-machine/FSND-Virtual-Machine/vagrant/visualization/static/images/my_plot4.png')
    plt.title("People from same state")
    plt.savefig('static/images/my_plot4.png')
    plt.close()
    return render_template('main.html', image_name = 'my_plot4.png')


if __name__ == '__main__':
    app.run(host='0.0.0.0')