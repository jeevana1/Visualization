### Project: Visualization 

This project interprets few **relations** in database
The provided python script **test.py** uses the **matplotlib** library to plot

## Requirements
- Python
- People JSON file
- Flask framework

## Execute command

1. run python file using "python test.py" command